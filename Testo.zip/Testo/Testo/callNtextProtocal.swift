//
//  callNtextProtocal.swift
//  Testo
//
//  Created by oskar morett on 2/11/17.
//  Copyright © 2017 oskar morett. All rights reserved.
//

import Foundation
protocol CellTextDelegate : NSObjectProtocol {
   
   
   func callTextButtonPressed(yesOrNo: Bool)

   
}

