//
//  Info.swift
//  Testo
//
//  Created by oskar morett on 2/8/17.
//  Copyright © 2017 oskar morett. All rights reserved.
//

import Foundation
import Contacts
import ContactsUI


var groupSelected : GroupSelected!

class GroupSelected {
   
   var name: String
   var idetifier: String
   
   init(name: String, idetifier: String) {
      self.name = name
      self.idetifier = idetifier
}

}
