//
//  Protocol.swift
//  Testo
//
//  Created by oskar morett on 2/8/17.
//  Copyright © 2017 oskar morett. All rights reserved.
//

import Foundation




protocol CellDelegate : NSObjectProtocol {
   
   
   func didSelectedSection(section: Int)
   
   
}


